﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            UpdateTool.AutoUpdate();                // 应用自动检测更新
            $safeprojectname$.DependentFiles.checksAll();     // 检测工具运行依赖文件

            Application.Run(new MainFrom());        // 显示修改工具主界面

        }
    }
}
